## Ana Konak.
## Mermi vectorü.
## Spritelar alınıp animasyon bağlancak. (DOTWEEN)
## Soldier ve Scientist yapılacak.
## Ana karakter child object olarak bağlancak.
## Yeni npc ai'yını interactable sisteme bağla.
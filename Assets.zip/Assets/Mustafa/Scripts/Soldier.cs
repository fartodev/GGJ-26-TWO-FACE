using UnityEngine;
using TestTunax; // SoldierSystem burada

namespace Eren
{
    public class Soldier : CombatCharacter
    {
        [Header("AI References")]
        // SoldierSystem'i buraya s�r�kle veya otomatik bulmas�na izin ver
        [SerializeField] private SoldierSystem _soldierSystem;

        protected override void Awake()
        {
            characterName = "Elite Soldier";

            // AI Scriptini otomatik bul
            if (_soldierSystem == null)
            {
                _soldierSystem = GetComponent<SoldierSystem>();
                // E�er kendinde yoksa child objelerde ara
                if (_soldierSystem == null)
                    _soldierSystem = GetComponentInChildren<SoldierSystem>();
            }

            base.Awake();
        }

        // 1. Ele ge�irildi�inde: AI'y� KAPAT
        public override void OnPossess()
        {
            base.OnPossess();

            if (_soldierSystem != null)
            {
                _soldierSystem.StopMove(); // Devriyeyi durdur (Tween kill)
                _soldierSystem.enabled = false; // Update fonksiyonunu durdur
            }
        }

        // 2. B�rak�ld���nda: AI'y� A�
        public override void OnDepossess()
        {
            base.OnDepossess();

            if (_soldierSystem != null)
            {
                _soldierSystem.enabled = true; // Update fonksiyonunu ba�lat
                _soldierSystem.MoveStart(); // Devriyeyi tekrar ba�lat
            }
        }
    }
}
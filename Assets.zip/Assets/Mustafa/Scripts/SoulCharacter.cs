using Game.Characters;
using UnityEngine;

namespace Mustafa
{
    public class SoulCharacter : BaseCharacter
    {
        [Header("Soul Settings")]
        [SerializeField] private float soulSpeed = 8f; // Ruh daha h�zl� olabilir
        [SerializeField] private Collider2D soulCollider;

        protected override void Awake()
        {
            base.Awake(); // UnitMotor'u al�r
            characterName = "The Soul";
            
            // Ruhun ba�lang�� h�z� ayar�
            if (TryGetComponent(out UnitMotor motor))
            {
                motor._moveSpeed = soulSpeed;
            }
        }

        // Ruhun �zel bir Action'� olabilir (�rne�in ba��r�p dikkat �ekmek)
        // �imdilik bo� b�rak�yoruz, sa� t�k (Possess) zaten InputManager'da.
        public override void Action() 
        {
            Debug.Log("Ruh formundas�n, bir bedene girmelisin!");
        }

        // Ruh hasar almaz (�l�ms�zl�k)
        // E�er HealthSystem eklersen, TakeDamage metodunu override edip bo� b�rakabilirsin.
    }
}
using UnityEngine;
using Eren; // IDamageable ve Combat sistemleri i�in
using Can;  // PossessionManager i�in

namespace Mustafa
{
    public class HealthSystem : MonoBehaviour, IDamageable
    {
        [Header("Status")]
        [SerializeField] private float maxHealth = 100f;
        [SerializeField] private float currentHealth;

        [Header("Death Settings")]
        [SerializeField] private GameObject deathEffect; // Patlama efekti (Opsiyonel)
        [SerializeField] private bool destroyOnDeath = true;

        private void Start()
        {
            currentHealth = maxHealth;
        }

        // Eren'in Bullet.cs'i veya WeaponSystem'i buray� �a��racak
        public void TakeDamage(float amount)
        {
            currentHealth -= amount;
            Debug.Log($"{gameObject.name} hasar ald�! [{currentHealth}/{maxHealth}]");

            if (currentHealth <= 0)
            {
                Die();
            }
        }

        private void Die()
        {
            // 1. �len ki�i �u an oyuncunun kontrol etti�i karakter mi?
            // (Interface oldu�u i�in cast edip kontrol ediyoruz)
            MonoBehaviour currentPossessedObj = PossessionManager.Instance.CurrentPossessed as MonoBehaviour;

            if (currentPossessedObj != null && currentPossessedObj.gameObject == this.gameObject)
            {
                Debug.LogWarning("OYUNCU �LD�! Ruh serbest kal�yor...");
                PossessionManager.Instance.Depossess();

                // �leride buraya "Game Over" veya "Ruh Moduna Ge�" ekran� eklenecek
            }
            else
            {
                Debug.Log($"D��man �ld�: {gameObject.name}");
            }

            // 2. Efekt varsa olu�tur
            if (deathEffect != null)
            {
                Instantiate(deathEffect, transform.position, Quaternion.identity);
            }

            // 3. Objeyi yok et
            if (destroyOnDeath)
            {
                Destroy(gameObject);
            }
        }

        public void Kill()
        {
            currentHealth = 0;
            Die(); // ��erideki standart �l�m mant���n� �al��t�r�r
        }

        // Test i�in d��ar�dan iyile�tirme fonksiyonu
        public void Heal(float amount)
        {
            currentHealth = Mathf.Min(currentHealth + amount, maxHealth);
        }
    }
}